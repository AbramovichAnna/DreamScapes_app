from django.contrib import admin
from .models import Sound, UserMix, Category, DreamUser

admin.site.register(Sound)
admin.site.register(UserMix)
admin.site.register(Category)
admin.site.register(DreamUser)
